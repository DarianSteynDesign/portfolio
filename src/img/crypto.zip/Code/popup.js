var dataControl = (function() {

    var symArray = [];

    var imgLinkArr = [],
        imgNameArr = [],
        fiatArray = [];

    var getTopHun = function(cb, sym2){
        var xhttp = new XMLHttpRequest();
        var response;

        xhttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                response = JSON.parse(this.responseText);

                var dataArray = $.map(response.data, function(value, index) {
                    return [value];
                });

                for (var i = 0; i < 100; i++) {
                    //console.log(dataArray[i].symbol);
                    if(dataArray[i].symbol == 'MIOTA'){
                        dataArray[i].symbol = 'IOT';
                    }
                    else if(dataArray[i].symbol == 'ETHOS'){
                        dataArray[i].symbol = 'BQX';
                    }
                    else if(dataArray[i].symbol == 'WICC'){
                        dataArray[i].symbol = 'WIC';
                    }
                    else if(dataArray[i].symbol == 'MOAC'){
                        dataArray[i].symbol = 'DRGN';
                    
                    }
                    else if(dataArray[i].symbol == 'CENNZ'){
                        dataArray[i].symbol = 'STORM';
                    } 
                    else if(dataArray[i].symbol == 'PAYX'){
                        dataArray[i].symbol = 'STORM';
                    }   
                    else if(dataArray[i].symbol == 'EMPR'){
                        dataArray[i].symbol = 'STORM';
                    }   
                    else if(dataArray[i].symbol == 'VET'){
                        dataArray[i].symbol = 'STORM';
                    }        
                    symArray.push(dataArray[i].symbol);
                }
                
            }
        }

        xhttp.open("GET", "https://api.coinmarketcap.com/v2/ticker/?start=1&limit=100&sort=rank", true);

        xhttp.send();
    }

    var getPrice = function(cb, sym1, sym2) {
        var xhttp = new XMLHttpRequest();
        var response, price1;
        //console.log(sym1, sym2);
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                response = JSON.parse(this.responseText);
                response = response[sym2];

                cb(null, response);

                document.getElementById('toggleLbl').classList.remove('loading');
            }
        };

        xhttp.open("GET", "https://min-api.cryptocompare.com/data/price?fsym=" + sym1 + "&tsyms=" + sym2 + "", true);

        xhttp.send();
    }

    var getImgUrl = function(cb, arr1) {
        var xhttp = new XMLHttpRequest();

        var response;

        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                response = JSON.parse(this.responseText);
                for (var i = 0; i < arr1.length; i++) {

                    //console.log(response.Data[arr1[i]].ImageUrl, arr1[i], i);

                    imgLinkArr.push(response.Data[arr1[i]].ImageUrl);
                    
                    imgNameArr.push(response.Data[arr1[i]].Symbol);

                }
                var avaiImgLength = Object.keys(response.Data).length,
                imgDataArray = Object.entries(response.Data).slice(0).map(entry => entry[0]);

                //console.log(imgDataArray);
                //console.log(imgNameArr);

                for(var i = 0; i < avaiImgLength; i++){
                    //console.log(imgDataArray[i]);
                    if(imgDataArray[i] === imgNameArr[i]){
                        console.log('equal');
                    }
                }

                cb(null, imgLinkArr, imgNameArr, uiControl.showSymLoad());
            }
        };

        xhttp.open('get', 'https://min-api.cryptocompare.com/data/all/coinlist');
        xhttp.send();
        
    }

    var getFiatList = function(cb) {
        var xhttp = new XMLHttpRequest();

        var response;
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                response = JSON.parse(xhttp.responseText);

                Object.keys(response).forEach(function(key) {
                    fiatArray.push(key);
                });

                cb(null, fiatArray);
            }
        };

        xhttp.open('get', 'currencyList.json');
        xhttp.send();
    };

    return {
        getItem: function(cb, sym1, sym2) {
            getPrice(cb, sym1, sym2);
        },
        calcNewPrice: function(price1, price2) {

            return price1 * price2;
        },
        getTopHun: function(cb){
            getTopHun(cb);
        },
        getImgUrl: function(cb) {
            getImgUrl(cb, symArray);
            console.log(symArray);
        },
        returnFiatList: function(cb) {
            getFiatList(cb);
        }
    }
})();

var uiControl = (function() {

    var domStrings = {
        sym1: 'sym1',
        sym2: 'sym2',
        toggleLbl: 'toggleLbl',
        symCont1: '.symContainer1',
        symCont2: '.symContainer2',
        coinCont: 'coinCont',
        priceSym1: 'priceSym1',
        priceSym2: 'priceSym2',
        cryptoPage: 'coinList1',
        fiatPage: 'coinList2',
        donateCont: 'donateContainer',
        donateBtn: 'donateBtn',
        searchInput: 'searchInput',
        coinList: 'coinList',
        symLoading: 'symLoading'
    }

    var whichSym, whichSearch;

    var createCoinList = function(arr, imgLink, imgName) {
        //console.log(imgLink);
        var newHtml = '<li><img class="coin-img" src="https://www.cryptocompare.com/' + imgLink + '"><p class="symText">' + imgName + '</p><a class="symLink" id="' + imgName + '"></a></li>';

        document.querySelector('#coinList1').insertAdjacentHTML('beforeend', newHtml);
    }

    var symCall = function(tar1, tar2) {
        dataControl.getItem(function(err, data) {
            uiControl.changeInput("1", data);
        }, tar1, tar2);
    }

    var createFiatList = function(fiatSym, fiatName) {
        var newHtml = '<li><a class="fiatText" id="' + fiatSym + '">' + fiatSym + '</a></li>';

        document.querySelector('#coinList2').insertAdjacentHTML('beforeend', newHtml);
    }

    return {
        changeInput: function(val1, val2) {
            var firstSym = document.getElementById(domStrings.sym1);
            if (!val1) {
                firstSym.value = "1";
            } else {
                firstSym.value = val1;
            }

            var secSym = document.getElementById(domStrings.sym2);
            secSym.value = val2;
        },
        getInput: function() {
            return {
                value: parseFloat(document.getElementById(domStrings.sym1).value)
            }
        },
        createCoinList: function() {
            dataControl.getImgUrl(function(err, data, data2) {
                for (var i = 0; i < data.length; i++) {
                    createCoinList(data, data[i], data2[i]);
                }
            });
        },
        createFiatList: function() {
            dataControl.returnFiatList(function(err, data) {
                for (var i = 0; i < data.length; i++) {
                    createFiatList(data[i]);
                }
            });
        },
        showCurrency: function() {
            document.getElementById(domStrings.coinCont).classList.toggle('active');
        },
        showCrypto: function() {
            document.getElementById(domStrings.cryptoPage).classList.toggle('inactive');
            document.getElementById(domStrings.fiatPage).classList.toggle('active');
        },
        showDonate: function() {
            document.getElementById(domStrings.donateCont).classList.toggle('active');
            document.getElementById(domStrings.donateBtn).classList.toggle('active');
            whichSearch = 1;
        },
        showFiat: function() {
            document.getElementById(domStrings.cryptoPage).classList.toggle('inactive');
            document.getElementById(domStrings.fiatPage).classList.toggle('active');
            whichSearch = 2;
        },
        showSymLoad: function(){
            console.log('remove');
            document.getElementById(domStrings.symLoading).classList.toggle('active');
        },
        checkWhichSym: function(event) {

            if (event.target.id === domStrings.priceSym1) {
                whichSym = "1";
            } else if (event.target.id === domStrings.priceSym2) {
                whichSym = "2";
            }
            return whichSym;
        },
        changeSym: function(event) {
            var target = event.target.id,
                target2;

            if (event.target.className === 'symLink') {
                var otherSym;

                if (whichSym === "1") {
                    otherSym = 2;
                    document.getElementById('priceSym' + whichSym).innerHTML = target;
                    target2 = document.getElementById('priceSym' + otherSym).innerHTML;
                    symCall(target, target2);
                } else if (whichSym === "2") {
                    otherSym = 1;
                    document.getElementById('priceSym' + whichSym).innerHTML = target;
                    target2 = document.getElementById('priceSym' + otherSym).innerHTML;
                    symCall(target2, target);
                }

                uiControl.showCurrency();

            }

            if (event.target.className === 'fiatText') {
                var otherSym;

                if (whichSym === "1") {
                    otherSym = 2;
                    document.getElementById('priceSym' + whichSym).innerHTML = target;
                    target2 = document.getElementById('priceSym' + otherSym).innerHTML;
                    symCall(target, target2);
                } else if (whichSym === "2") {
                    otherSym = 1;
                    document.getElementById('priceSym' + whichSym).innerHTML = target;
                    target2 = document.getElementById('priceSym' + otherSym).innerHTML;
                    symCall(target2, target);
                }

                uiControl.showCurrency();

            }
        },
        getSyms: function() {
            var value1 = document.getElementById(domStrings.priceSym1).textContent;
            var value2 = document.getElementById(domStrings.priceSym2).textContent;

            return {
                val1: value1,
                val2: value2
            }
        },
        searchFunc: function() {
            var input, filter, list, listItem, check;
            input = document.getElementById(domStrings.searchInput);
            filter = input.value.toUpperCase();

            console.log(domStrings.coinList + whichSearch);
            if (whichSearch === undefined) {
                whichSearch = 1;
            }
            list = document.getElementById(domStrings.coinList + whichSearch);
            listItem = list.getElementsByTagName('li');

            for (var i = 0; i < listItem.length; i++) {
                check = listItem[i].getElementsByTagName("a")[0];
                if (check.id.toUpperCase().indexOf(filter) > -1) {
                    listItem[i].style.display = "";
                } else {
                    listItem[i].style.display = "none";
                }
            }
        }
    }
})();

var controller = (function(dataCtrl, uiCtrl) {
    var setupEventListeners = function() {
        //Toggle Prices
        document.getElementById('toggleLbl').addEventListener('click', changePrice);
        //Enter the value
        document.addEventListener('keypress', function(event) {
            if (event.keyCode === 13 || event.which === 13) {
                changePrice();
            }
        });

        //Show Currency page
        document.getElementById('priceSym1').addEventListener('click', function(event) {
            uiCtrl.showCurrency();
            uiCtrl.checkWhichSym(event);
        });
        document.getElementById('priceSym2').addEventListener('click', function(event) {
            uiCtrl.showCurrency();
            uiCtrl.checkWhichSym(event);
        });

        //Close Currency page
        document.getElementById('closeBtn').addEventListener('click', uiCtrl.showCurrency);

        //Click on symbol page
        document.querySelector('body').addEventListener('click', uiCtrl.changeSym);

        //Show fiat page
        document.getElementById('fiatBtn').addEventListener('click', uiCtrl.showFiat);

        //Show fiat page
        document.getElementById('cryptoBtn').addEventListener('click', uiCtrl.showCrypto);

        //Show donate page
        document.getElementById('donateBtn').addEventListener('click', uiCtrl.showDonate);

        //Search function
        document.getElementById('searchInput').addEventListener('keyup', uiControl.searchFunc);

    }
    var changePrice = function() {
        var input = uiCtrl.getInput(); // You have to create a variable with the method call, otherwise it wont store the values

        if (input.desc !== "" && !isNaN(input.value) && input.value > 0) {

            var sym1 = uiCtrl.getSyms().val1,
                sym2 = uiCtrl.getSyms().val2;

            dataCtrl.getItem(function(err, data) {
                var result = dataCtrl.calcNewPrice(input.value, data);
                uiCtrl.changeInput(input.value, result);
            }, sym1, sym2);

        }
    }
    return {
        init: function() {
            setupEventListeners();

            uiCtrl.createCoinList();
            uiCtrl.createFiatList();

            var sym1 = uiCtrl.getSyms().val1,
                sym2 = uiCtrl.getSyms().val2;

            dataCtrl.getItem(function(err, data) {
                uiCtrl.changeInput("1", data);
            }, sym1, sym2);

            dataCtrl.getTopHun();

        }
    };
})(dataControl, uiControl);

controller.init();